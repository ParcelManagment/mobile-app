const FontSize = {
    small: 16,
    medium: 20,
    large: 28,
    xLarge: 32,
    xxLarge: 36,
};
export default FontSize;
