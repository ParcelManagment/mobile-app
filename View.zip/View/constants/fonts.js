const Font = {
  "Inter-regular": "Inter-Regular",
};
export default Font;
