const Colors = {
    primary: "#fbbc41",
    white: "#ffffff",
    black: "#000000",
    text: "#2c3e50",
    gray: '#f8f4f4',
    medium: "#6e6969",
    light: "#f1f1f1",
    danger: "#ff5252",
};

export default Colors;