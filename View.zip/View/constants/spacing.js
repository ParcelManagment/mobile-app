const Spacing = 10;
export default Spacing;